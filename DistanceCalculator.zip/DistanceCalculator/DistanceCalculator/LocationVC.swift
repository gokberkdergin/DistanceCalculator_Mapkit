//
//  LocationVC.swift
//  DistanceCalculator
//
//  Created by Gökberk on 20.08.2020.
//  Copyright © 2020 Laika. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class LocationVC: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var buttonOutlet: UIButton!
    @IBOutlet weak var distanceLabel: UILabel!
    var distance = 0.0
    var price = 0.0
    var senderLong = 148.001
    var senderLat = 148.001
    var targetLong = 148.001
    var targetLat = 148.001
    @IBOutlet weak var map: MKMapView!
    var myMap = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        findmyLocation()
        buttonOutlet.isHidden = false
        distanceLabel.isHidden = true
        
    }
    
    @objc func deliveryLocation(gestureRecognizer:UILongPressGestureRecognizer){
        
        if gestureRecognizer.state == .began {
            let touchedPoint = gestureRecognizer.location(in: map)
            let touchedCoordinate = map.convert(touchedPoint, toCoordinateFrom: map)
            let annotation = MKPointAnnotation()
            annotation.coordinate = touchedCoordinate
            annotation.title = "2nd Location"
            map.addAnnotation(annotation)
            let latitude = touchedCoordinate.latitude
            let longitude = touchedCoordinate.longitude
            targetLat = touchedCoordinate.latitude
            targetLong = touchedCoordinate.longitude
            
            
            let ceo: CLGeocoder = CLGeocoder()
            let address : CLLocation = CLLocation(latitude: latitude, longitude: longitude)
            ceo.reverseGeocodeLocation(address, completionHandler:
                {(placemarks, error) in
                    if (error != nil)
                    {
                        print("reverse geodcode fail: \(error!.localizedDescription)")
                    }
                    let pm = placemarks! as [CLPlacemark]

                    if pm.count > 0 {
                        let pm = placemarks![0]
                        var addressString : String = ""
                        if pm.subLocality != nil {
                            addressString = addressString + pm.subLocality! + ", "
                        }
                        if pm.thoroughfare != nil {
                            addressString = addressString + pm.thoroughfare! + ", "
                        }
                        if pm.locality != nil {
                            addressString = addressString + pm.locality! + ", "
                        }
                        if pm.country != nil {
                            addressString = addressString + pm.country! + ", "
                        }
                        if pm.postalCode != nil {
                            addressString = addressString + pm.postalCode! + " "
                        }

                        print(addressString)
                        self.distancecalculate()
                        //self.deliveryAddress.isHidden = false
                        //self.deliveryAddress.text = "\(addressString) "
                        //self.cost()
                  }
            })}
    }
    
    func findmyLocation() {
           
           myMap.delegate = self
           myMap.desiredAccuracy = kCLLocationAccuracyBest
           myMap.requestWhenInUseAuthorization()
           myMap.startUpdatingLocation()
           map.showsUserLocation = true
           
       }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
     
     let userLocation : CLLocation = locations[0] as CLLocation
     myMap.stopUpdatingLocation()
     let alan = CLLocationCoordinate2D(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
     let aralik = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
     let bolge = MKCoordinateRegion(center: alan, span: aralik)
     map.setRegion(bolge, animated: true)
     senderLong = userLocation.coordinate.longitude
     senderLat = userLocation.coordinate.latitude
     
     let ceo: CLGeocoder = CLGeocoder()
     let address : CLLocation = CLLocation(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
     ceo.reverseGeocodeLocation(address, completionHandler:
             {(placemarks, error) in
                 if (error != nil)
                 {
                     print("reverse geodcode fail: \(error!.localizedDescription)")
                 }
                 let pm = placemarks! as [CLPlacemark]

                 if pm.count > 0 {
                     let pm = placemarks![0]
                     var addressString : String = ""
                     if pm.subLocality != nil {
                         addressString = addressString + pm.subLocality! + ", "
                     }
                     if pm.thoroughfare != nil {
                         addressString = addressString + pm.thoroughfare! + ", "
                     }
                     if pm.locality != nil {
                         addressString = addressString + pm.locality! + ", "
                     }
                     if pm.country != nil {
                         addressString = addressString + pm.country! + ", "
                     }
                     if pm.postalCode != nil {
                         addressString = addressString + pm.postalCode! + " "
                     }
                     
                    
               }
         })
    }
    


    @IBAction func button(_ sender: Any) {
        navigationItem.title = "Choose 2nd Location"
            let gestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(deliveryLocation(gestureRecognizer:)))
            gestureRecognizer.minimumPressDuration = 3
            map.addGestureRecognizer(gestureRecognizer)
        buttonOutlet.isHidden = true
        
            
        }
    
    
    func distancecalculate() {
    
    let p1 = CLLocation(latitude: senderLat, longitude: senderLong)
    let p2 = CLLocation(latitude: targetLat, longitude: targetLong)
    distance = p2.distance(from: p1)
    distance = (distance/0.62) / 1000
    let dist = Int(distance)
    distanceLabel.isHidden = false
    distanceLabel.text = "\(dist) KM"
    
}
}
